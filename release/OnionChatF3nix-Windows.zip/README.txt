OnionChatF3nix - Build para Windows

1) Ejecuta OnionChatF3nix.exe
2) Requiere Tor/Tor Browser activo

Generado automaticamente desde main.py

Limite de envio/recepcion de archivos: 20 MB

