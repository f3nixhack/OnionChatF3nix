OnionChatF3nix - Build para Windows

1) Ejecuta OnionChatF3nix.exe
2) Requiere Tor/Tor Browser activo

Generado automaticamente desde main.py
