ONIONCHATF3NIX - GUIA RAPIDA (Windows)

1) Requisitos
- Windows 10/11.
- Tor activo (Tor Browser abierto o servicio Tor en ejecucion).

2) Inicio
- Ejecuta OnionChatF3nix.exe.
- Pulsa "Detectar Tor".

3) Crear chat
- Pulsa "Crear chat onion".
- Comparte tu direccion .onion.

4) Conectarse
- Pega la direccion .onion recibida.
- Pulsa "Conectar".

5) Archivos
- Maximo 5 MB por archivo.
- Descargas en: Descargas\OnionChatF3nix
